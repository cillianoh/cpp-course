#include <iostream>
#include <string>
using namespace std;

// sum the digits of a number until it is only one digit
// state if the final digit is divisible by three
int main(int argc, char *argv[])
{
    string valueString = argv[1];
    size_t value = 0;

    while (valueString.length() > 1){       // while value >=10
        value = 0;
        for (const char& el: valueString){  // sum digits
            value += el - '0';
        }
        valueString = to_string(value);     // assign sum to string
    }

    string divByThree{'3', '6', '9'};
    cout << (divByThree.find(valueString)   // if final value is divisible by 3
            ? "\" not divisible by 3"       // output correct statement
            : "\" divisible by 3");
    
}