#include <iostream>
using namespace std;

// input: int; 
//output : value inputted, binary value, numeric value of it's set bits
int main(int argc, char *argv[])
{
    int input = atoi(argv[1]);

    cout << input << " = ";

    int nBits = sizeof(input) * 8;                  // no. of bits in input 
    int bits[nBits];

    for (int indx = 0; indx < nBits; indx++){       // transferring bits from
        bits[indx] = (input & 1);                   // input to array
        input = input >> 1;
    }

    for (int indx = nBits - 1; indx >= 0; indx--){  //outputting bits reversed
        cout << bits[indx];
    }

    bool first = true;
    for (int indx = nBits - 1; indx >= 0; indx--){  
        if (bits[indx] == 1 && first == true){      // if there is a bit and 
            cout << " = " << (1 << indx);           // it is the first one
            first = false;                          // output '=' and value
        }

        else if (bits[indx] == 1){                  // else if there is a bit
            cout << " + " << (1 << indx);           // output '+' and value
        }
    }
}