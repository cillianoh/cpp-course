#include <iostream>
#include <string>
using namespace std;

// remove blanks before and after a string extracted from the input stream
// output the results
int main () 
{
   string line;        
   getline(cin, line, '\n');                //assign input stream to string

   string blanks{ ' ', '\r', '\t' };        //string containing all blank chars

   size_t startIndx = line.find_first_not_of(blanks);//index of first non-blank
   size_t endIndx = line.find_last_not_of(blanks);   //index of last non-blank
      
  string final = line.substr(startIndx, endIndx - startIndx + 1);
                                            //substring created between indexs
   
   cout << '`' << final << "'\n";           //print final output
                    
    
}
