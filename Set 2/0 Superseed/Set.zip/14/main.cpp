#include <iostream>
using namespace std;

// compute the square root of a number by estimating it using a given function
int main()							
{
    double input;
    cout << "Enter a value to compute the sqrt of (<=0 to stop): ";
        cin >> input;                          //extract first no.
    
    while (input > 0){
    
        double x0 = 0;                         //initialise variables so
        double x1 = 1;                         //for loop can start
        for (int indx = 1;x0 != x1; indx++){   //for loop stops when sqrt found
            x0 = x1;                           //correctly initialise variables
            x1 = 0;

            x1 = x0 + (input - (x0 * x0)) / (2 * x0);
                                               //implent given formula

            cout << indx << ": x0: " << x0 << ", x1 = " << x1
                 << ", sqr is: " << x1 * x1 << '\n';
                                               //output formatted step

        }
        cout << "sqrt(" << input << ") is " << x1 << '\n';
                                               //output formatted results

        cout << "Enter a value to compute the sqrt of (<=0 to stop): ";
        cin >> input;                          //ask for second input
    }
}